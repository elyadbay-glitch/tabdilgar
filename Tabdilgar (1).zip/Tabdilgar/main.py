import os
import threading
from flask import Flask
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
from persiantools.jdatetime import JalaliDate
from hijri_converter import convert
from datetime import datetime

# -------------------
# Flask server
# -------------------
app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is running!"

def run():
    app.run(host="0.0.0.0", port=8080)

# -------------------
# Telegram Bot
# -------------------
TOKEN = os.environ.get("TOKEN")  # توکن رو از Environment Variables می‌گیره

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("سلام 👋\nتاریخ رو بفرست تا برات تبدیل کنم!")

async def convert_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    try:
        # فرض: تاریخ ورودی میلادی به شکل YYYY-MM-DD
        g_date = datetime.strptime(text, "%Y-%m-%d").date()

        # میلادی → شمسی
        j_date = JalaliDate(g_date)

        # میلادی → قمری
        h_date = convert.Gregorian(g_date.year, g_date.month, g_date.day).to_hijri()

        reply = (
            f"📅 تاریخ میلادی: {g_date.strftime('%Y-%m-%d')}\n"
            f"🇮🇷 شمسی: {j_date}\n"
            f"☪️ قمری: {h_date}"
        )
        await update.message.reply_text(reply)
    except Exception:
        await update.message.reply_text("❌ لطفاً تاریخ رو به فرمت YYYY-MM-DD بفرست.")

def main():
    app_telegram = ApplicationBuilder().token(TOKEN).build()

    app_telegram.add_handler(CommandHandler("start", start))
    app_telegram.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, convert_date))

    # اجرای Flask در ترد جدا
    threading.Thread(target=run).start()

    # اجرای ربات
    app_telegram.run_polling()

if __name__ == "__main__":
    main()