from server import keep_alive
keep_alive()

import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, CallbackQueryHandler, MessageHandler, filters
from khayyam import JalaliDate
from hijridate import Hijri, Gregorian

# گرفتن توکن از سکرت
TOKEN = os.environ["BOT_TOKEN"]

# نگهداری وضعیت کاربر
user_choice = {}

# شروع ربات
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("🔢 تبدیل تاریخ", callback_data="convert_date")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "👋 سلام! من ربات تبدیل تاریخ هستم.\n\n"
        "می‌تونم تاریخ‌ها رو بین **شمسی، میلادی و قمری** تبدیل کنم 🌍🕌📅",
        reply_markup=reply_markup
    )

# انتخاب دکمه
async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_choice[query.from_user.id] = query.data
    await query.message.reply_text(
        "📅 لطفاً تاریخ رو وارد کن:\n\n"
        "⚠️ فرمت صحیح: `yyyy/mm/dd`\n"
        "➖ مثال: `1404/07/05`",
        parse_mode="Markdown"
    )

# پردازش پیام
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id not in user_choice:
        await update.message.reply_text("لطفاً اول از /start استفاده کن 🙂")
        return

    text = update.message.text.strip()

    try:
        # تاریخ ورودی
        y, m, d = map(int, text.split("/"))

        # محاسبه تاریخ‌ها
        j_date = JalaliDate(y, m, d)   # شمسی
        g_date = j_date.todate()       # میلادی
        h_date = Gregorian(g_date.year, g_date.month, g_date.day).to_hijri()  # قمری

        # نمایش نتیجه زیبا
        result = (
            "✨ نتایج تبدیل تاریخ ✨\n\n"
            f"🇮🇷 شمسی: *{j_date}*\n"
            f"🌍 میلادی: *{g_date}*\n"
            f"🕌 قمری: *{h_date}*\n\n"
            "✅ تاریخ‌ها با موفقیت تبدیل شدند!"
        )
        await update.message.reply_text(result, parse_mode="Markdown")

    except Exception as e:
        await update.message.reply_text(
            "❌ فرمت تاریخ اشتباهه!\n\n"
            "⚠️ باید به شکل `yyyy/mm/dd` باشه.\n"
            "➖ مثال درست: `1404/07/05`",
            parse_mode="Markdown"
        )

# اجرای ربات
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(button))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

print("✅ ربات در حال اجراست...")
app.run_polling()